﻿CREATE TABLE [dbo].[Product]
(
    [Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [Name] VARCHAR(50) NULL,
    [Price] INT NULL,
    [Stock] INT NULL,
    [Unit] INT NULL,
    [Category] VARCHAR(50) NULL
);
GO

CREATE TABLE [dbo].[Category]
(
    [Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [CategoryItem] VARCHAR(50) NULL
);
GO

CREATE TABLE [dbo].[History]
(
    [Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [ProductID] INT NULL,
    [AddedStocks] INT NULL,
    [Date] DATETIME NULL
);
GO

CREATE TABLE [dbo].[Cart]
(
    [Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [Name] VARCHAR(50) NULL,
    [Price] INT NULL,
    [Quantity] INT NULL,
    [ProductId] INT NULL,
    [Uid] INT NULL
);
GO

CREATE TABLE [dbo].[Transaction]
(
    [Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [Date] DATETIME NULL,
    [Subtotal] VARCHAR(50) NULL,
    [Cash] VARCHAR(50) NULL,
    [DiscountPercent] VARCHAR(50) NULL,
    [DiscountAmount] VARCHAR(50) NULL,
    [Total] VARCHAR(50) NULL,
    [Change] VARCHAR(50) NULL,
    [TransactionId] VARCHAR(MAX) NULL,
    [Uid] INT NULL
);
GO

CREATE TABLE [dbo].[Orders]
(
    [Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
    [TransactionId] VARCHAR(MAX) NULL,
    [Name] VARCHAR(50) NULL,
    [Price] VARCHAR(50) NULL,
    [Quantity] INT NULL
);
GO

CREATE TABLE [dbo].[Account]
(
    [Uid] INT NOT NULL PRIMARY KEY IDENTITY (1000, 1),
    [Username] VARCHAR(50) NULL,
    [Password] VARCHAR(50) NULL,
    [Email] VARCHAR(50) NULL
);
GO

