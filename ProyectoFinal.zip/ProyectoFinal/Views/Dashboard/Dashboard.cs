﻿using System.Windows.Forms;

namespace InventoryApp.Views.Dashboard
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }
    }
}
