﻿public static class UserSession
{
    public static int SessionUID { get; set; }
}
